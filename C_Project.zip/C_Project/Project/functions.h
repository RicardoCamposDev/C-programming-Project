#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#define MAXSTR 1024

void getstr(char str[],size_t len)
{
	char buffer[MAXSTR];
	fgets(buffer,MAXSTR,stdin);
	buffer[strcspn(buffer,"\n")]='\0';

	if(strlen(buffer)<len)
		strcpy(str,buffer);
	else
	{
		strncpy(str,buffer,len-1);
		str[len-1]='\0';
	}
}


long getidade(){

	char buffer[MAXSTR];
	fgets(buffer,MAXSTR,stdin);
	buffer[strcspn(buffer,"\n")]='\0';

	char *err=NULL;
	long val=strtol(buffer,&err,10);

	if(strlen(err)!=0)
		printf("Valor(es) errados [%s]\n",err);
	return val;
}
