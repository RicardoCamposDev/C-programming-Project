#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "functions.h"

#define max 51
#define DIM 5

typedef struct{ //Estrutura que armazena os formandos
    char nome[max];
    int idade;
}formando;

formando formandos[DIM]; //Cria��o de uma estrutura do tipo definido

//Declara��o das fun��es (Cabe�alhos das fun��es)
void inserirFormando();
void listarFormandos();
void procurarFormando(char *nomeFormando);

int main()
{

int option = 0;
int sair = 0;
char nome_formando[max]; //vari�vel que armazena o nome que ser� usado na procura do formando usando a fun��o strcmp()

do{

    printf("\n\n************ Registo Formandos ***********\n\n"); //Menu do programa
    printf("\n1.Inserir novo formando.");
    printf("\n2.Listar formandos.");
    printf("\n3.Procurar formando.");
    printf("\n4.Sair.\n");
    printf("\nInserir opcao:\n");
    scanf("%d", &option);


    while (option < 1 || option > 4){ //Em caso de inser��o de op��o errada
        printf("\nOpcao errada!!! Por favor insira novamente: ");
        scanf("%d", &option);
    }

        switch(option){
            case 1: //Inserir formandos
                    inserirFormando();

            break;
            case 2: //Listar formandos
                    listarFormandos();
            break;
            case 3: //Procurar formando
                    fflush(stdin);
                    printf("Introduza o nome do formando: ");
                    getstr(nome_formando,max);
                    procurarFormando(nome_formando);
            break;
            case 4:
                    sair = 1; //Sair do programa
            break;
        }

}while(!sair);

}

///////////////// Implementa��o das fun��es //////////////////////////////////

void inserirFormando(){


    //Inicializar vector de estrutura
    for(int x = 0; x < DIM; x++){
        strcpy(formandos[x].nome, "NULL");
        formandos[x].idade = 0;

    }

    printf("\nPor favor introduza formandos:\n");

    for(int i=0;i<DIM;i++){ //Carregar os dados dos formandos

        fflush(stdin);
        printf("\nFormando %d:\n", (i+1));
        printf("Nome: ");
        getstr(formandos[i].nome,max);

        printf("Idade: ");
        formandos[i].idade= getidade();

    }
}

void listarFormandos(){

    //Listar cada um dos formandos
    for(int i = 0; i < DIM; i++){
        printf("\nFormando %d\n", (i + 1));
        printf("Nome: %s\n", formandos[i].nome);
        printf("Idade: %d\n", formandos[i].idade);
    }
}

void procurarFormando(char *nomeFormando){ //Procurar um formando pelo nome usando a fun��o strcmp()

    int formando_existe = 0;

    for( int i = 0; i < DIM; i++){
            int comp = strcmp(nomeFormando, formandos[i].nome);

            if( comp == 0){
                printf("\nDados do Formando:\n");
                printf("Nome: %s\n", formandos[i].nome);
                printf("Idade: %d\n", formandos[i].idade);
                formando_existe = 1;
            }
    }

    if(!formando_existe){
            printf("\nO Formando nao existe!!!");
    }

}


